package modles;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import org.h2.engine.Database;
import org.h2.engine.User;

import play.data.validation.Constraints;
import play.data.validation.ValidationError;

@Entity
public class Player extends User{
	
	public Player(Database arg0, int arg1, String arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public enum Geschlecht {
		maennlich, weiblich
	}
	
	private String vorname;
	private String nachname;
	
	private String geburtsdatum;
	public List<ValidationError> validate() {
		List<ValidationError> errors = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		dateFormat.setLenient(false);
 
		try {
			// Wenn das GebDat nicht geparst werden kann, wird eine Exception geworfen
			Date date = dateFormat.parse(geburtsdatum);
			System.out.println(date);
 
		} catch (ParseException e) {
			errors = new ArrayList<ValidationError>();
			errors.add(new ValidationError("geburtsdatum", "Das Datum muss vom Forma DD/MM/YYYY sein!"));
		}
		return errors;
	}
	
	
	private Geschlecht geschlecht;
	
	@Constraints.Required
	@Id
	@Constraints.MinLength(4)
	@Constraints.MaxLength(8)
	private String benutzername;
	
	@Constraints.Required
	@Constraints.MinLength(4)
	@Constraints.MaxLength(8)
	private String passwort;
	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(String geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	public Geschlecht getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(Geschlecht geschlecht) {
		this.geschlecht = geschlecht;
	}

	public String getBenutzername() {
		return benutzername;
	}

	public void setBenutzername(String benutzername) {
		this.benutzername = benutzername;
	}

	public String getPasswort() {
		return passwort;
	}

	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}
	
		
}
