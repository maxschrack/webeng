package controllers;

import play.*;
import play.mvc.*;
import views.html.*;
//import views.html.authentication;

public class Application extends Controller {
	
	@play.db.jpa.Transactional
    public static Result index() {
		return ok(authentication.render());
    }
	
	@play.db.jpa.Transactional
    public static Result registration() {
		return ok(registration.render());
    }
}
